# Kane's Wrath Patch Switcher

Community tools for Command & Conquer 3: Kane's Wrath. Switch between R25i and the repaired R25j core, launch through Steam or the local game executable, and browse or import custom maps.

## R25j Fixes R3 Community Repack

[Download Setup-v2.exe from Google Drive](https://drive.google.com/open?id=1CBeP_MI1TMVld3dz2g4C1cWW1VGrC595)

[Project page on ModDB](https://www.moddb.com/mods/kanes-wrath-patch-switcher-r25j-fixes-r3-community-repack)

The single-file installer includes the repaired R25j gameplay core, four official R25j archives, and six custom maps. The 4K add-on is optional and separate. Close the game and WorldBuilder before installing or switching.

## Source layout

- `switcher/` contains the current Windows Forms app and PowerShell patch switching logic.
- `installer/` contains the earlier R3 installation engine and Setup Wizard source. It installs four custom maps and expects a 26-file payload. It is not the source of the six-map Setup-v2 download above.

Build with the .NET Framework C# compiler and reference System.Windows.Forms, System.Drawing, System.IO.Compression, and System.IO.Compression.FileSystem.

## Game folder layout

The switcher runs from the Kane's Wrath game folder, beside `CNC3EP1.exe`. The patch files themselves are not in this repository; the Community Repack installer puts them in place. The switcher expects:

```
<game folder>/
  CNC3EP1.exe
  Patch Switcher.exe                      built from switcher/PatchSwitcher.cs
  Patch103/                               the live patch the game loads
  R25j-repair/
    Switch-Patch.ps1
    R25i-Restore-2026-11-06/Payload/Patch103/    R25i core files and map archives
    Patch-Switcher-R25j-Fixes-R2/                repaired R25j core files
    R25j-Full-Repaired/Payload/Patch103/         R25j map archives
    ExtraPatchProfiles/                          created by "Add patch folder..."
```

Core files are `102Scripts.big`, `102texturefix.big`, and `config.txt`. Each switch saves the files it replaces in `Patch103/switch-backup-<id>` and keeps only the most recent backup. If the live patch has been edited or is incomplete, pick a patch and press Switch to repair it.

Thanks to Masterleaf and the Kane's Wrath mapmakers, testers, and players.
